const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 8080 });

wss.on('connection', ws => {
  console.log('Client connected');

  // Simulate detection of .exe file opening
  setTimeout(() => {
    ws.send(JSON.stringify({ status: 'connected' }));
  }, 1000);
});
