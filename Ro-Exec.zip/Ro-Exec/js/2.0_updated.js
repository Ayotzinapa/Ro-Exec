let unlock = false;

let p_Connected = document.getElementById('mzdxv');
let p_DisConnected = document.getElementById('p_DisConnected');
let p_Warn = document.getElementById('p_Warn');
let h_Connected = document.getElementById('h_Connected');
let h_DisConnected = document.getElementById('h_DisConnected');
let p_Restart = document.getElementById('h_Warn');
let langx = document.getElementById('language');
let inject_text = document.getElementById('inject_text');
let x_droped = document.getElementById('x_droped');
let hidden_back = document.getElementById('hidden_back');
let hub_drop = document.getElementById('hub_drop');

h_Connected.style.display = "none";
p_Warn.style.display = "none";
p_Restart.style.display = "none";

var RoBlox_Gay = 0;

langx.addEventListener('change', function() {
    let selectedValue = langx.value;
    if (selectedValue == "2") {
        inject_text.textContent = "yup";
        inject_text.style.fontFamily = "Kanit, sans-serif";
    } else if (selectedValue == "1") {
        inject_text.textContent = "Please inject to unlock";
        inject_text.style.fontFamily = "Roboto, sans-serif";
    } else if (selectedValue == "3") {
        inject_text.textContent = "Пожалуйста, введите, чтобы разблокировать";
        inject_text.style.fontFamily = "Roboto, sans-serif";
    } else if (selectedValue == "4") {
        inject_text.textContent = "請注入解鎖";
        inject_text.style.fontFamily = "Roboto, sans-serif";
    }
});

async function check_Server() {
    const ws = new WebSocket('ws://localhost:8050/ws');
    ws.onopen = async function() {
        p_Connected.style.display = "block";
        h_Connected.style.display = "block";
        p_DisConnected.style.display = "none";
        p_Warn.style.display = "none";
        h_DisConnected.style.display = "none";
        p_Restart.style.display = "none";
        x_droped.style.display = "none";
    };
    ws.onclose = function() {
        p_Connected.style.display = "none";
        h_Connected.style.display = "none";
        p_Restart.style.display = "none";
        p_Warn.style.display = "none";
        x_droped.style.display = "none";
        p_DisConnected.style.display = "block";
        h_DisConnected.style.display = "block";
    };
    ws.onerror = function(error) {
        p_Connected.style.display = "none";
        h_Connected.style.display = "none";
        p_DisConnected.style.display = "none";
        h_DisConnected.style.display = "none";
        p_Restart.style.display = "block";
        p_Warn.style.display = "block";
        console.log(error);
    };
}

async function Uptime() {
    setInterval(function() {
        check_Server();
    }, 200);
}

async function sendMessage() {
    unlock = true;
    if (unlock) {
        const message = editor.getValue();
        if (!message) {
            alert('Please enter some text in the text area.');
            return;
        }
        if (message == "hub()") {
            hub_drop.style.display = "block";
        }
        try {
            const ws = new WebSocket('wss://localhost:8050/ws');
            ws.onopen = function() {
                ws.send(message);
            };
            ws.onmessage = function(event) {
                alert('Message from server: ' + event.data);
            };
            ws.onclose = function() {
                p_Connected.style.display = "none";
                h_Connected.style.display = "none";
                p_Restart.style.display = "none";
                p_Warn.style.display = "none";
                p_DisConnected.style.display = "block";
                h_DisConnected.style.display = "block";
            };
            ws.onerror = function(error) {
                p_Connected.style.display = "none";
                h_Connected.style.display = "none";
                p_DisConnected.style.display = "none";
                h_DisConnected.style.display = "none";
                p_Restart.style.display = "block";
                p_Warn.style.display = "block";
                console.log(error);
            };
        } catch (error) {
            alert('WebSocket connection error: ' + error.message);
        }
    } else {
        alert('No inject detected !');
        window.location = "https://discord.gg/TUzTGVq2RS";
    }
}

document.addEventListener('keydown', (event) => {
    if (event.ctrlKey && event.key === 'u') {
        event.preventDefault();
    }
});

(function() {
    let isDevToolsOpen = false;
    const threshold = 160;

    function checkDevTools() {
        const widthThreshold = window.outerWidth - window.innerWidth > threshold;
        const heightThreshold = window.outerHeight - window.innerHeight > threshold;
        isDevToolsOpen = widthThreshold || heightThreshold;
    }

    setInterval(checkDevTools, 1000);

    setInterval(() => {
        if (isDevToolsOpen) {
            // Optional: Handle DevTools detection here
        }
    }, 1000);
})();

// Function to handle the transition from h_DisConnected to h_Green
function handleF20HW1BN1Press() {
    h_DisConnected.style.display = "block"; // Show the disconnected element

    setTimeout(() => {
        h_DisConnected.style.display = "none"; // Hide the disconnected element
        let h_Green = document.getElementById('h_Green'); // Ensure h_Green exists in your HTML
        if (h_Green) {
            h_Green.style.display = "block"; // Show the green element
        } else {
            console.error('Element with id "h_Green" not found.');
        }
    }, 5000); // 5000 milliseconds = 5 seconds
}

// Assuming you have a mechanism to call this function when f20hw1bn1.exe is pressed
// For demonstration, using a button click as a trigger
let button = document.getElementById('triggerButton'); // Replace with the actual ID or method of triggering
if (button) {
    button.addEventListener('click', handleF20HW1BN1Press);
} else {
    console.error('Button with id "triggerButton" not found.');
}
